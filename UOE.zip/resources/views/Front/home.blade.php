@extends('Front.main')
@section('content')
@include('partials.banner')
@include('partials.features')
@include('partials.services')
@endsection
