<!-- Start Footer
    ============================================= -->
<footer class="bg-dark text-light" style="background-image: url({{asset('assets/img/shape/8.png')}});">
    <div class="container">
        <div class="f-items default-padding">
            <div class="row">

                <!-- Single Itme -->
                <div class="col-lg-4 col-md-6 item">
                    <div class="footer-item about">
                        <img class="logo" src="https://www.uoeld.ac.ke/themes/uoeld/logo.png" alt="Logo">
                        <p>
                            Welcome to the UOE Farm Management System. Login to manage different aspects of the farm.
                        </p>
                        <form action="#">
                            <input type="email" placeholder="Your Email" class="form-control" name="email">
                            <button type="submit"> Go</button>
                        </form>
                    </div>
                </div>
                <!-- End Single Itme -->

                <!-- Single Itme -->
                <div class="col-lg-2 col-md-6 item">
                    <div class="footer-item link">
                        <h4 class="widget-title">Explore</h4>
                        <ul>
                            <li>
                                <a href="/about">About Us</a>
                            </li>
                            <li>
                                <a href="/team">Meet Our Team</a>
                            </li>
                            <li>
                                <a href="/blog">News & Media</a>
                            </li>
                            <li>
                                <a href="/projects">Projects</a>
                            </li>
                            <li>
                                <a href="/contact">Contact Us</a>
                            </li>
                            <li>
                                <a href="/gallery">Gallery</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- End Single Itme -->

                <!-- Single Itme -->
                <div class="col-lg-3 col-md-6 item">
                    <div class="footer-item recent-post">
                        <h4 class="widget-title">Recent Posts</h4>
                        <ul>
                            <li>
                                <div class="thumb">
                                    <a href="#">
                                        <img src="assets/img/800x800.png" alt="Thumb">
                                    </a>
                                </div>
                                <div class="info">
                                    <div class="meta-title">
                                        <span class="post-date">12 Sep, 2023</span>
                                    </div>
                                    <h5><a href="#">Meant widow equal an share least part. </a></h5>
                                </div>
                            </li>
                            <li>
                                <div class="thumb">
                                    <a href="#">
                                        <img src="assets/img/800x800.png" alt="Thumb">
                                    </a>
                                </div>
                                <div class="info">
                                    <div class="meta-title">
                                        <span class="post-date">18 Jul, 2023</span>
                                    </div>
                                    <h5><a href="#">Future Plan & Strategy for Consutruction </a></h5>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- End Single Itme -->

                <!-- Single Itme -->
                <div class="col-lg-3 col-md-6 item">
                    <div class="footer-item contact">
                        <h4 class="widget-title">Contact Info</h4>
                        <ul>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-home"></i>
                                </div>
                                <div class="content">
                                    <strong>Address:</strong>
                                    University of Eldoret
                                    P.O. Box 1125-30100
                                    Eldoret, Kenya.
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="content">
                                    <strong>Email:</strong>
                                    <a href="mailto:info@info@uoeld.ac.ke">info@info@uoeld.ac.ke</a>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="content">
                                    <strong>Phone:</strong>
                                    <a href="tel:+254 746 490 082">+254 746 490 082</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Single Itme -->

            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom text-center">
            <div class="row">
                <div class="col-lg-12">
                    <p>&copy; Copyright {{date('Y')}}. All Rights Reserved by <a href="#">University of Eldoret</a></p>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </div>
    <div class="shape-right-bottom">
        <img src="{{asset('assets/img/shape/7.png')}}" alt="Image Not Found">
    </div>
</footer>
<!-- End Footer -->
